# Spec-Forge Glossary

The shared vocabulary every skill in this framework thinks with. These are **leading words** — compact terms that anchor a whole region of behaviour. When the same word lives in your spec, your notes, and these skills, the agent links them and acts more predictably.

**Spec** — a living architecture document, not a PRD. It describes *what components exist, how they connect, and which decisions are still open*. It survives many builds. It is the thing this framework forges and keeps current.

**Slice** — a vertical cut from trigger to result that runs end-to-end. Not a layer (DB, then API, then UI). The unit of build and of readiness. A slice is either forgeable, blocked, or shipped.

**Invariant** — a part of the architecture that does not change when a **variation point** swaps. The worktree model, the merge queue, the slice structure. Naming invariants is how you avoid rewriting the whole spec when one piece changes.

**Variation point** — a place the architecture could swap one choice for another (Claude Code → Hermes; Obsidian → GitHub). Each carries a **coupling** rating: how much else breaks if it swaps. High coupling means the swap is a project, not an edit.

**Assumption** — a claim the spec depends on that has not been verified against a live source. "noSandbox() works with wt.run()" is an assumption until the `.d.ts` confirms it. Every assumption carries a **confidence** and a **gate class**.

**Gate class** — how urgent an assumption is. Three values: **blocker** (verify before building this slice), **gate** (verify before *using* a feature, not before building the slice), **later** (documentation only, no build risk). Mislabelling a gate as a blocker stalls you; mislabelling a blocker as a gate breaks the build.

**Confidence** — a 0–100% honest estimate of whether an assumption holds, tied to the *evidence*, not the feeling. "70% — the README says yes but a parenthetical says no" is a real confidence. "90% — I remember it working" is not; that is parametric memory, which this framework never trusts for a live fact.

**Live source** — the current, authoritative form of a fact: the installed `.d.ts`, this week's CHANGELOG, an empirical test run. The opposite of parametric memory and of last-month's README. Assumptions are verified against live sources, never against recollection.

**Round** — one bounded, focused pass over the spec. A round has a stated focus ("verify API correctness"), names the sections it touches, and declares whether it gates the next build. Rounds are the normal way a spec evolves.

**Rewrite** — a full restructure, reserved for when an invariant is falsified or the slice order inverts. Rare. Most changes that feel like they need a rewrite need a **round** or a **variation document** instead.

**Variation document** — a sibling file that holds a speculative **variation point** (e.g. Hermes-as-agent) with its open questions and a decision tree, *without* touching the stable spec. Keeps the baseline uncluttered until the variation is real enough to fold in.

**Forgeable** — a slice whose assumptions are all resolved to blocker-clear, whose dependencies are shipped or in-scope, and whose exit criteria are checkable. The readiness verdict that green-lights a build.

**Lesson** — a short, self-contained teaching moment surfaced *during* the work, tied to the decision on the table right now. The unit of the teach-alongside skill. Never abstract; always about the choice you are making this minute.
