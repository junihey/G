# Spec-Forge

A skill framework for forging an **architecture spec** — a living design document that survives many builds — and keeping it current as tools change and ideas arrive.

It is deliberately *upstream* of Matt Pocock's `mattpocock/skills`. Where his `/grill-me → /to-spec → /to-tickets` takes a design you already hold and turns it into a PRD and issues, Spec-Forge is for the phase before that: when the architecture itself is still in flux, assumptions are unverified, and new ideas keep threatening to force a rewrite. You run Spec-Forge first, then hand its validated slices to `/to-spec` and `/to-tickets`.

Written to the conventions in Matt's `writing-great-skills`: user-invoked skills (zero context load), one leading-word vocabulary shared across all of them ([`GLOSSARY.md`](./GLOSSARY.md)), checkable completion criteria, and a router.

## What's in it

| Skill | What it does | When you reach for it |
| --- | --- | --- |
| `/forge` | Router over the others | Start here; whenever you're unsure which skill fits |
| `/scope` | Carve out in/out + spec exit criteria | First step of a new spec |
| `/baseline` | Turn external dependencies into an installed, version-pinned environment | After scope, before skeleton |
| `/skeleton` | Components and connections, on paper | After baseline |
| `/variability` | Mark invariants vs variation points | After skeleton |
| `/validate` | Surface + verify assumptions against live sources | After variability |
| `/slice-plan` | Order the build into vertical slices | After validate |
| `/readiness` | Per-slice go/no-go before building | Before every build |
| `/integrate` | Route a new idea: round, variation doc, or rewrite | Whenever an idea arrives |
| `/refresh` | Check components for updates + better alternatives | On a cadence, or before a build |
| `/teach-alongside` | Continuous teaching tied to each decision | Turn on at the start, runs throughout |

## Installation

### Option A — as a Claude Code plugin (recommended)

1. Put this folder somewhere stable, e.g. `~/dev/spec-forge`.
2. Symlink each skill into your agent's skills directory:

   ```bash
   for skill in ~/dev/spec-forge/skills/*/; do
     ln -s "$skill" ~/.claude/skills/"$(basename "$skill")"
   done
   ```

   (Adjust `~/.claude/skills` to your harness; the same layout works for any harness that reads the open SKILL.md spec.)
3. A `git pull` on the folder keeps every installed skill current, since they're symlinks.

### Option B — copy into a single project

Drop the `skills/` subfolders and `GLOSSARY.md` into that project's `.claude/skills/`. Good when a spec is tied to one repo. Keep `GLOSSARY.md` reachable — every skill points at it.

### Option C — run it here, no install

You don't have to install anything to use the *method*. Paste a skill's steps into a chat and follow them. You lose autocompletion and the `/name` trigger, but the process is identical.

## Step-by-step: forging a spec from zero

The first pass through a new spec runs the first five skills in order, one session each, with teaching on throughout.

1. **`/teach-alongside`** — turn teaching on first, so every decision below comes with its *why*. It writes `lessons-learned.md` beside the spec.
2. **`/scope`** — four questions, one at a time: minimum scope, what's explicitly out, external dependencies, and how you'll know the *spec* is done. Output: a scope statement written to the spec's top.
3. **`/baseline`** — walk scope's external-dependency table and actually install, pair, or confirm each one, version-pinned, with an end-to-end smoke test. Output: an infrastructure baseline table that `/validate` and `/refresh` point at as their live source.
4. **`/skeleton`** — entry points, state, compute, integrations, decision points. Output: a one-screen Mermaid diagram (structure only — rationale stays in prose beside it).
5. **`/variability`** — walk each component, mark it invariant or a variation point, rate coupling, build the matrix, and name what must not change. Output: an invariant list + variation matrix. Speculative alternatives get handed to `/integrate`, not written inline.
6. **`/validate`** — pull every assumption out of the scope, skeleton, and matrix; rate each by confidence and gate class; and *actually verify the blockers* against live sources (installed `.d.ts`, this week's changelog, a two-line empirical run — or the baseline table from step 3). For more than a handful of blockers, dispatch each as a parallel **legwork task** to a sub-agent rather than checking inline. Output: an assumptions checklist where every blocker reads verified or falsified.
7. **`/slice-plan`** — find the floor slice, build a card per slice with checkable exit criteria and a named verification discipline (**falsify first** by default — reproduce, confirm red, fix, confirm green, full regression), draw the dependency graph. Output: an ordered slice plan.
8. **`/readiness`** — run the four-part forgeable test on each slice. Output: a build-now list and a parked list, each parked slice with its single unblock condition.

Then, downstream: Matt's `/to-spec` turns the validated spec into a PRD, `/to-tickets` breaks the slices into issues, and `/tdd` builds each one.

## Step-by-step: keeping a spec alive

Once forged, a spec lives. Three loops keep it current:

- **A new idea** → `/integrate`. It routes to a **round** (bounded change, most ideas), a **variation document** (speculative swap kept beside the spec, baseline untouched), or a **rewrite** (rare — only when an invariant falls). New claims go through `/validate`; then re-run `/readiness`.
- **Time passing** → `/refresh` on a cadence. It diffs each component against its live source for version drift, decayed assumptions, and fixed bugs whose workarounds you can now delete, and scans variation points for better alternatives. Findings route through `/integrate`; then re-run `/readiness`.
- **Before any build** → `/readiness`. It's a function of the *current* spec, never a fact you record once. Re-run it after every validate, integrate, or refresh.

## The design contract

Three properties hold across every skill, and they're the point of the framework:

- **Never trust parametric memory for a live fact.** Anything about a tool's current API, flags, or behaviour is verified against a live source. `/validate` and `/refresh` enforce this; `/teach-alongside` obeys it too.
- **Change lands at a named seam.** Because `/variability` names invariants and variation points up front, a new idea in `/integrate` is a swap at a known place — not a shock that forces a rewrite.
- **Building is gated, not assumed.** `/readiness` stands between the plan and the build, and its verdict is always re-computed against the current spec so it can't go quietly stale.
